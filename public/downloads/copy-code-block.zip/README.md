copy-code-block.ts의 경우 아래처럼 스크립트 태그 아래에 적용해야 하고

```html
<script is:inline>
  /* copy-code-block.ts 내용 */
</script>
```

copy-code-block.css의 경우엔 .astro 파일의 style 태그 사이에 추가해야함

```html
<style>
  /* copy-code-block.css 내용 */
</style>
```
