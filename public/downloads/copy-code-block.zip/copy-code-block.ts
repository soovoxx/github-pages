(() => {
  const codeBlocks = Array.from(document.querySelectorAll("pre > code"));
  if (!codeBlocks.length) return;

  const copyIcon = `
          <svg aria-hidden="true" focusable="false" class="icon" viewBox="0 0 24 24">
            <path d="M9 3h10a2 2 0 0 1 2 2v12h-2V5H9V3Zm-4 4h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Zm0 2v10h10V9H5Z" fill="currentColor"/>
          </svg>`;
  const checkIcon = `
          <svg aria-hidden="true" focusable="false" class="icon" viewBox="0 0 24 24">
            <path d="m9.6 16.2-3.8-3.8 1.4-1.4 2.4 2.4 7.2-7.2 1.4 1.4-8.6 8.6Z" fill="currentColor"/>
          </svg>`;

  codeBlocks.forEach((codeEl) => {
    const pre = codeEl.parentElement;
    if (!pre || pre.querySelector(".code-copy")) return;

    pre.dataset.codeBlock = "true";

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "code-copy";
    btn.innerHTML = `${copyIcon}<span class="sr-only">코드 복사</span>`;
    btn.setAttribute("aria-label", "코드 복사");

    btn.addEventListener("click", async () => {
      const text = codeEl.innerText;
      try {
        await navigator.clipboard.writeText(text);
        btn.innerHTML = `${checkIcon}<span class="sr-only">복사 완료</span>`;
        btn.classList.add("copied");
      } catch (err) {
        btn.innerHTML = `${copyIcon}<span class="sr-only">복사 실패</span>`;
        console.error("Copy failed", err);
      } finally {
        setTimeout(() => {
          btn.innerHTML = `${copyIcon}<span class="sr-only">코드 복사</span>`;
          btn.classList.remove("copied");
        }, 1400);
      }
    });

    pre.appendChild(btn);
  });
})();
